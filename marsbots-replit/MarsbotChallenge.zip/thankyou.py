import PySimpleGUI as sg

def thanks():
  sg.popup('Game Over', 'Thanks for playing',
    font=('Sans',20))
